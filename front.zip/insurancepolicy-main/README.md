## Node version
> 20.9.0
## NPM version
> 10.2.3

### Setup
> cd to directory and run
  - `npm i`
  - `npm run dev`

***Happy developing!***

## creating a vite project
> npm create vite@latest app_name
> choose react
> choose javascript
> cd into the directory and
> npm i
> npm run dev
> follow the whole tailwind vite setup
