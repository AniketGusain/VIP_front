import React from 'react'
import PolicyRequests from '../tabulator/PolicyRequests'
function ViewRequests() {
  return (
    <div>
      <PolicyRequests/>
    </div>
  )
}

export default ViewRequests
