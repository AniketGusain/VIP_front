import React from "react";
import AppliedPolicies from "../../tabulator/appliedPolicies";
function Appliedpolicies() {
  return (
    <div>
      All the applied polices here
      <AppliedPolicies />
    </div>
  );
}

export default Appliedpolicies;
