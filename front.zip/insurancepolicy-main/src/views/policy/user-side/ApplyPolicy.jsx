import React from 'react'
import AvailablePolices from "../../../components/policygrid/Policygrid"
function ApplyPolicy() {
  return (
    <div>
      <>
        <AvailablePolices/>
      </>
    </div>
  )
}

export default ApplyPolicy
